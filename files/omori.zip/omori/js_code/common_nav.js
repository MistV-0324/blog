const common_nav_title = document.querySelector('.common_nav h2')
const Line_nav = document.querySelector('.Line_nav')
const Lines = document.querySelectorAll('.Line')
const pluto = document.querySelector('.pluto')
const four_person = document.querySelector('.four')
let y = 0
//点击黄色标题部分，显示出4条“线路”
common_nav_title.addEventListener('click',function(){
    y++
    if(y===1){
    Line_nav.style.opacity = 1
    Line_nav.style.transform = 'translateY(0px)'
    }
    if(y===2){
    Line_nav.style.opacity = 0
    Line_nav.style.transform = 'translateY(-36px)'
    y = 0
    }
})
Lines.forEach(function(Line,index){   //遍历4个页面的线路
Line.addEventListener('click',function(e){
    pluto.style.backgroundImage = 'url(images/Character/pluto_fly_5.2s.gif)'
    setTimeout(function(){
        pluto.style.top = '-40px' 
    },4300)
    setTimeout(function(){
        pluto.style.opacity = 0  //起飞的过程中消失
    },4100)
    setTimeout(function(){ //四个小人消失，切换图片，并且进行一段位移，待会人物出现时会显得更加自然
        pluto.style.backgroundImage = 'url(images/Character/pluto_and_four.gif)'
        pluto.style.top = '-80px'
        four_person.style.opacity = 0
    },5000)
    setTimeout(function(){
        pluto.style.opacity = 1
    },5400)
    setTimeout(function(){
        pluto.style.top = '-500px'
    },6000)
    setTimeout(function(){  //小人消失后紧接着就是页面的跳转
        pluto.style.opacity = 0
    },7300)
    setTimeout(function(){ //最后就是通过环境对象中的className来获取点击的对象的类名，并且进行页面的跳转
        if(e.target.className ==='Line Line1'){
            window.location.href ='Homepage.html'
        }
        if(e.target.className ==='Line Line2'){
            window.location.href =`Rw-Album_page.html`
        }
        if(e.target.className ==='Line Line3'){
            window.location.href ='Dw-Album_page.html'
        }
        if(e.target.className ==='Line Line4'){
            window.location.href ='Content_page.html'
        }
        if(e.target.className ==='Line Line5'){
            window.location.href ='Login_page.html'
        }
    },7450)
})
})