const pagesArr = document.querySelectorAll('.page') //获取所有页面元素
const nextBtn = document.querySelector('.next') //获取下一页按钮
const prevBtn = document.querySelector('.prev') //获取上一页按钮
let i = 0 //设置当前页面索引
//遍历所有页面
pagesArr.forEach(function(page, index) {
  //给每个页面添加点击事件
  page.addEventListener('click', function() {
    const currentPage = this; //当前点击的页面
    const currentHalfPageLeft = this.children[1] //当前页面的左半页
    const currentHalfPageRight = this.children[2] //当前页面的右半页
    currentHalfPageRight.style.transform = 'rotateY(-180deg)' //将当前右半页翻转
    currentHalfPageLeft.style.opacity = 0 //同时设置当前左半页的透明度为0，使其不可见
    setTimeout(function() {
      currentPage.style.zIndex = 0 //等待1秒后，设置当前页的层叠顺序为0，使其在其他页面之下
      currentHalfPageLeft.style.zIndex = 0 //同样设置当前半页的层叠顺序
      currentHalfPageRight.style.zIndex = 0 //同样设置当前半页的层叠顺序
    }, 1000)

    currentHalfPageRight.style.opacity = 0 //设置当前半页的透明度为0，使其不可见
    currentHalfPageLeft.style.opacity = 0 //设置当前半页的透明度为0，使其不可见
    currentPage.style.opacity = 0 //设置当前页的透明度为0，使其不可见

  })
})

// 当用户进入页面时，后退按钮的状态变为禁用
if(i === 0){
    prevBtn.disabled = true
    prevBtn.style.backgroundImage = 'url(images/Album-Real_world/gray-left_hand.png)'
}
//为下一页按钮添加点击事件
nextBtn.addEventListener('click', function() {
  if (i < pagesArr.length - 1) {
    pagesArr[i].click() //模拟点击当前页，使其翻页
    i++ //增加页面索引
    nextBtn.disabled = false
    nextBtn.style.backgroundImage = 'url(images/Album-Real_world/right_hand.png)'
    prevBtn.disabled = false
    prevBtn.style.backgroundImage = 'url(images/Album-Real_world/left_hand.png)'
  }

  // 如果到达最后一页，禁用下一页按钮
  if (i === pagesArr.length - 1) {
    nextBtn.disabled = true
    nextBtn.style.backgroundImage = 'url(images/Album-Real_world/gray-right_hand.png)'
  }
});
prevBtn.addEventListener('click',function(){
  if (i > 0) {
    const zIndexARR = [8,7,6,5,4,3,2,1]
    const currentPage = pagesArr[i] //当前点击的页面
    const currentHalfPageLeft = currentPage.children[1] //当前页面的左半页
    const currentHalfPageRight = currentPage.children[2] //当前页面的右半页
    // 前页
    const previousPage = pagesArr[i].previousElementSibling //上一个页面
    const previousHalfPageLeft = previousPage.children[1]   //上一个页面的左半页
    const previousHalfPageRight = previousPage.children[2]  //上一个页面的右半页
    // 后页
// 当前页面的左半页翻转时，当前页面的透明度为0，随后使上一个页面的透明度为1
    previousHalfPageRight.style.transform = 'rotateY(0deg)'  //恢复上一个左页面的状态
    currentHalfPageLeft.style.transform = 'rotateY(180deg)' //点击当前的左页面
    previousPage.style.zIndex = zIndexARR[i]
    previousHalfPageLeft.style.zIndex = zIndexARR[i]
    previousHalfPageRight.style.zIndex = zIndexARR[i]
    i--
    setTimeout(function(){
    previousHalfPageLeft.style.opacity = 1 
    },300)
    setTimeout(function(){
    previousPage.style.opacity = 1
    },360)
    previousHalfPageRight.style.opacity = 1
    currentHalfPageRight.style.opacity = 0 //设置当前半页的透明度为0，使其不可见
    currentHalfPageLeft.style.opacity = 0 //设置当前半页的透明度为0，使其不可见
    currentPage.style.opacity = 0 //设置当前页的透明度为0，使其不可见
    previousPage.style.zIndex = zIndexARR[i]
    previousHalfPageLeft.style.zIndex = zIndexARR[i]
    previousHalfPageRight.style.zIndex = zIndexARR[i]
    // 当左翻页翻到第一页时，则遍历所有页,并让它们的左半页“归位”
    if(i===0){
        for (let j = i; j < pagesArr.length; j++) {
            setTimeout(function() {
                pagesArr[j].children[1].style.transform = 'rotateY(0deg)'
            }, 0)
        }
    }
    // 当左翻页翻到第一页时，则遍历所有页的opacity的值为1
    if(i===0){
        setTimeout(function(){
            for (let j = i; j < pagesArr.length; j++) {
                pagesArr[j].style.opacity = 1
                 // 如果每一页都由左右两个半页组成，也需要将这两个半页的opacity设置为1
                pagesArr[j].children[1].style.opacity = 1 //左半页
                pagesArr[j].children[2].style.opacity = 1 //右半页
            }
        },1000)  //添加延迟函数是为了过渡自然
    }
    nextBtn.disabled = false
    nextBtn.style.backgroundImage = 'url(images/Album-Real_world/right_hand.png)'
    }
  // 最后，当左页面翻转到第一页时，禁用prev按钮    
  if(i===0){
      prevBtn.disabled = true
      prevBtn.style.backgroundImage = 'url(images/Album-Real_world/gray-left_hand.png)'
  }
})
const Album_title = document.querySelector('.Album_title')
const photos = Array.from(document.querySelectorAll('.photo_half'))
const pageBox = document.querySelector('.page_box')  //相册盒子
const gallery_box = document.querySelector('.photo_gallery') //图片展示盒子
const gallery_box_img = document.querySelector('.photo_gallery img') //图片展示盒子
const shift_key = document.querySelector('.shift_key') //shift盒子
const gallery_textBox = document.querySelector('.photo_galleryText') //日志文本盒子
const gallery_title = document.querySelector('.photo_galleryText h4')//日志标题
const gallery_text = document.querySelector('.photo_galleryText p') //日志文本
const photoArr = [
{url:'images/Album-Head_space/DW_ALBUM_01.png',title:'风车森林',text:'MARI正在教大家如何编花冠！OMORI和KEL正举着MARI做好的样品。真漂亮...'},
{url:'images/Album-Head_space/DW_ALBUM_02.png',title:'风车森林',text:'OMORI和KEL最后还是偷偷溜走了，但AUBREY和我很快就掌握了制作方法！'},
{url:'images/Album-Head_space/DW_ALBUM_03.png',title:'风车森林',text:'HERO还在试着编花冠。虽然这画了他不少时间，这种坚持不懈的精神真让人敬佩。'},
{url:'images/Album-Head_space/DW_ALBUM_04.png',title:'风车森林',text:'大家一起吃西瓜。美味多汁！AUBREY的脸上沾了几粒西瓜籽。或许有人该告诉她一声。'},
{url:'images/Album-Head_space/DW_ALBUM_05.png',title:'风车森林',text:'KEL正在喝他最喜欢的牛奶，我还是别靠他太近了，不然我的相机可能就要遭殃啦。'},
{url:'images/Album-Head_space/DW_ALBUM_06.png',title:'风车森林',text:'MARI让HERO给我们拍了张照。大家一致认为花冠很适合我。'},
{url:'images/Album-Head_space/DW_ALBUM_07.png',title:'风车森林',text:'HERO准备凑过去亲亲抱抱！KEL看上去很不耐烦。啊，兄弟情...'},
{url:'images/Album-Head_space/DW_ALBUM_08.png',title:'森林游乐场',text:'我们今天一起去野餐了！MARI想给大家拍一张照。说‘茄子’！'},
{url:'images/Album-Head_space/DW_ALBUM_09.png',title:'森林游乐场',text:'除了HERO和MARI，大家都在吃完东西后睡倒了。我自己也有点困了。'},
{url:'images/Album-Head_space/DW_ALBUM_10.png',title:'森林游乐场',text:'KEL说这张照片只是个小小的意外，我对此表示怀疑....'},
{url:'images/Album-Head_space/DW_ALBUM_11.png',title:'森林游乐场',text:'大家的脚排成了一圈！猜猜看这些脚分别是谁的？'},
{url:'images/Album-Head_space/DW_ALBUM_12.png',title:'风车森林',text:'我最好的朋友们... KEL、AUBREY、HERO、MARI和OMORI！我会永远珍惜他们的。'},
{url:'images/Album-Head_space/DW_ALBUM_13.png',title:'贝瑟尔的家',text:'今天大家都帮我浇了我的植物！每当我开始和大家讨论植物时，我往往会唠叨太久，但是我真的很感谢我的朋友们能够耐心倾听！'},
{url:'images/Album-Head_space/DW_ALBUM_14.png',title:'太空垃圾场',text:'我们在垃圾场找到了一张旧沙发！沙发上虽然只能勉强挤下四人，但我们都丝毫不介意。因为我们有整个世界最好的视野！'},
{url:'images/Album-Head_space/DW_ALBUM_15.png',title:'幽灵派对',text:'一只蜘蛛突然从树上掉了下来，吓了大家一跳！HERO甚至看都不敢看'},
{url:'images/Album-Head_space/DW_ALBUM_16.png',title:'甜心城堡',text:`哦，伙计们！我们能够得到五张"SWEETHEART'S QUEST FOR HEARTS"的票！我真希望没有什么意外发生...`},
{url:'images/Album-Head_space/DW_ALBUM_17.png',title:'最后度假村',text:'我们在最后度假村！KEL一直在老虎机上输。哈哈，他真的应该学会什么时候该停手。'},
{url:'images/Album-Head_space/DW_ALBUM_18.png',title:'芥末之家',text:'我们在MUSTARD SUB停下来吃点吃的，每个人都有美味可口的套餐！！'}
] 
photos.forEach(function(photo,index){
photo.addEventListener('click',function(e){
    e.stopPropagation() //阻止冒泡，这样子点击图片，也不会受到父元素的点击切换页数的效果影响
    pageBox.style.top = '150%'  //相册盒子位移到底部
    pageBox.style.opacity = 0  //相册盒子位移的同时隐藏
    gallery_box.style.bottom = 0 //图片展示盒子从底部往上弹出
    gallery_box.style.opacity =1  //图片展示盒子弹出的时候同时进行显现
    nextBtn.style.opacity = 0
    prevBtn.style.opacity = 0
    gallery_box_img.src = photoArr[index].url //根据点击到的图片，进行实时切换
    gallery_title.innerHTML = photoArr[index].title
    gallery_text.innerHTML = photoArr[index].text
    Album_title.style.opacity = 0 //标题隐藏
})
})
let xCount = 0  //用来追踪按下x键的次数
document.addEventListener('keyup',function(e){
// console.log(e);
if(e.key === 'Shift'){   //首字母必须大写
    shift_key.style.opacity = 0  //shift盒子隐藏
    gallery_textBox.style.bottom = 0  //日志文本盒子弹出
    gallery_textBox.style.opacity = 1  //日志文本盒子显示
}
if(e.key === 'x'){
    xCount++
    if(xCount===1){
    shift_key.style.opacity = 1  //shift盒子隐藏
    gallery_textBox.style.bottom = 1  //日志文本盒子弹出
    gallery_textBox.style.opacity = 0  //日志文本盒子显示
    }
    if(xCount===2){
        //复原点击图片之前的相册状态
        pageBox.style.top = '-9.14%'
        pageBox.style.opacity = 1
        gallery_box.style.bottom ='-200%'
        gallery_box.style.opacity = 0
        nextBtn.style.opacity = 1
        prevBtn.style.opacity = 1
        Album_title.style.opacity = 1
        xCount = 0 //次数归0

    }
}
})