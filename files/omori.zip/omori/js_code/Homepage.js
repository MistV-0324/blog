    // 固定导航的显现
    const fx_nav = document.querySelector('.fixed_nav_box')
    // 1、知识点：scrollTop，offsetTop
    // 获取header的高度，并且使其到达固定位置时颜色加深
    function scHeader(){
        // document.documentElement 是html元素的获取方式，想要获取页面的中被卷去的高度，必须要获取html元素
        // scrollTop为可读写属性，可读写的意思：就是既可以获取，又可以赋值
        const sctop = document.documentElement.scrollTop
        const content = document.querySelector('.content')
        const contentOt = content.offsetTop
        if(sctop >= contentOt){  //sctop 是页面滚动的高度，而offsetTop元素的上边距。这两个值不太可能完全相等。所以可以使用一个范围来判断是否滚动到了指定位置。
            fx_nav.style.backgroundColor =' rgba(63, 7, 153)'
            fx_nav.style.opacity = 1
            fx_nav.style.top = '0px'
        }
        else{
            fx_nav.style.backgroundColor = 'rgba(63, 7, 153, .3)'
            fx_nav.style.opacity = 0
            fx_nav.style.top = '-30px'
        }
    }
    window.addEventListener('scroll', scHeader)

//轮播图的制作
    let i = 0;
    // 遍历小图片
    const smallImgs = document.querySelectorAll('.small_img_group img')
    const small_img_group = document.querySelector('.small_img_group')
    const slide_texts = document.querySelectorAll('.slide_content .text')
    let slide = document.querySelector('.slide_content')
    
      for (let j = 0; j < smallImgs.length; j++) {
        // 遍历小图片的点击事件
        smallImgs[j].addEventListener('click', function() {
          document.querySelector('.active').classList.remove('active');  //当小图片发生点击时，去除原有的active样式，去除原有样式的同时，给新的小图片添加active样式，我称之为“排他”思想
          document.querySelector(`.small_img_group img:nth-child(${j+1})`).classList.add('active') 
          slide.style.transform = `translateX(-${j * 20}%)`  //随着j数值的改变，slide的内部内容的位移也会随之变化
          i = j  //这样就能进行点击图片后，进行数值的实时同步
        })
      }
    
    //定时器
    let time = setInterval(function() {
      i++
      if (i >= document.querySelectorAll('.slide_content li').length) {  //无缝衔接的关键
        i = 0
      }
      document.querySelector('.active').classList.remove('active')
      document.querySelector(`.small_img_group img:nth-child(${i+1})`).classList.add('active')  /* 排他 */
      slide.style.transform = `translateX(-${i * 20}%)`
    }, 4000)
    
    //鼠标悬停在盒子上时停止定时器
    slide.addEventListener('mouseenter', function() {
      clearInterval(time)   //关闭定时器
      small_img_group.style.bottom = '3%'   //图片盒子向上移动
      slide_texts.forEach(function(text) {   //所有的文本盒子也向上移动
        text.style.bottom = 0
      });
      small_img_group.addEventListener('mouseenter',function(){   //给小图片组添加滑动事件，当鼠标移动到小图片盒子时，盒子和文本部分保持原位
        slide_texts.forEach(function(text) {
        text.style.bottom = 0
      })
            small_img_group.style.bottom = '3%'
        })
    })
    
    //鼠标悬停在盒子上时开启定时器
    slide.addEventListener('mouseleave', function() {
      time = setInterval(function() {
        i++
        if (i >= document.querySelectorAll('.slide_content li').length) {
          i = 0
        }
        document.querySelector('.active').classList.remove('active')
        document.querySelector(`.small_img_group img:nth-child(${i+1})`).classList.add('active')  /* 排他 */
        slide.style.transform = `translateX(-${i * 20}%)`
      }, 4000)
      small_img_group.style.bottom = '-16.8%'
      slide_texts.forEach(function(text) {
        text.style.bottom = '-20%'
      })
    })
//角色选项卡
    const dw = document.querySelector('.selection_box .dw')
    const rw = document.querySelector('.selection_box .rw')
    const headshot_imgs = document.querySelectorAll('.headshot img')
    const headshot_p = document.querySelectorAll('.headshot p')
    const rw_headshotArr = [
        {url:'images/Character/Sunny_rw.png',text:'SUNNY'},
        {url:'images/Character/RW_Aubrey.png',text:'AUBREY'},
        {url:'images/Character/RW_Kel.png',text:'KEL'},
        {url:'images/Character/RW_Hero.png',text:'HERO'},
        {url:'images/Character/RW_Basil.png',text:'BASIL'},
        {url:'images/Character/RW_Mari.png',text:'MARI'},
        {url:'images/Character/Kim_Portrait.png',text:'KIM'},
        {url:'images/Character/Vance_Portrait.png',text:'VANCE'},
        {url:'images/Character/Angel_Portrait.png',text:'ANGEL'},
        {url:'images/Character/Charlene_Portrait.png',text:'CHARLENE'},
        {url:'images/Character/The_Maverick_Portrait.png',text:'MIKHAEL'},
        {url:'images/Character/Something_Portrait.png',text:'SOMETHING'}
    ]
    const dw_headshotArr = [
        {url:'images/Character/Omori_dw.png',text:'SUNNY'},
        {url:'images/Character/DW_Aubrey_dw.png',text:'AUBREY'},
        {url:'images/Character/DW_Kel_dw.png',text:'KEL'},
        {url:'images/Character/DW_Hero_dw.png',text:'HERO'},
        {url:'images/Character/DW_Basil.png',text:'BASIL'},
        {url:'images/Character/DW_Mari.png',text:'MARI'},
        {url:'images/Character/Pluto_Portrait.png',text:'PLUTO'},
        {url:'images/Character/Spaceboy_Portrait.png',text:'VANCE'},
        {url:'images/Character/Sweetheart_Portrait.png',text:'SPACEBOY'},
        {url:'images/Character/Mr_Jawsum_Portrait.png',text:'SWEETHEART'},
        {url:'images/Character/Humphrey_Portrait.png',text:'MR.JAWSUM'},
        {url:'images/Character/Stranger.png',text:'STRANGER'}
    ]
    // 遍历角色头像中的每一张图片和文本
    headshot_imgs.forEach(function(img,index){
        rw.addEventListener('click',function(){
            img.src = rw_headshotArr[index].url
            img.style.backgroundColor = 'black'
            dw.style.borderBottom = 'none'
            rw.style.borderBottom = '5px solid #6c0eff'
            //图片显现的瞬间消失和显现的小动画
            img.style.opacity = 0 
            setTimeout(function(){
                img.style.transition = 'all 1s'
            },1) //瞬间改变图片和文字的过渡时长
            setTimeout(function(){
                img.style.opacity = 1
            },200)  //2s后自然显现
            setTimeout(function(){
                img.style.transition = 'all 0.01s'
            },1200)  //1.2s后换回原来的过渡时长
        })
        dw.addEventListener('click',function(){
            img.src = dw_headshotArr[index].url
            img.style.backgroundColor = '#6c0eff'
            dw.style.borderBottom = '5px solid #6c0eff'
            rw.style.borderBottom = 'none'
            //图片显现的瞬间消失和显现的小动画
            img.style.opacity = 0 
            setTimeout(function(){
                img.style.transition = 'all 1s'
            },1) //瞬间改变图片和文字的过渡时长
            setTimeout(function(){
                img.style.opacity = 1
            },200)  //0.2s后自然显现
            setTimeout(function(){
                img.style.transition = 'all 0.01s'
            },1200)  //1.2s后换回原来的过渡时长
        })
    })
    headshot_p.forEach(function(p,index){
        rw.addEventListener('click',function(){
            p.innerHTML = rw_headshotArr[index].text
            p.style.backgroundColor = 'black'
            p.style.opacity = 0 
            setTimeout(function(){
                p.style.transition = 'all 1s'
            },1)
            setTimeout(function(){
                p.style.opacity = 1
            },200)
            setTimeout(function(){
                p.style.transition = 'all 0.01s'
            },1200)  //1.2s后换回原来的过渡时长
        })
        dw.addEventListener('click',function(){
            p.innerHTML = dw_headshotArr[index].text
            p.style.backgroundColor = '#6c0eff'
            p.style.opacity = 0 
            setTimeout(function(){
                p.style.transition = 'all 1s'
            },1)
            setTimeout(function(){
                p.style.opacity = 1
            },200)
            setTimeout(function(){
                p.style.transition = 'all 0.01s'
            },1200)  //1.2s后换回原来的过渡时长
        })
    })
//电梯导航
    // 使用querySelectorAll方法选择所有包含href属性值以"#"开头的.nav a元素
    const lift_nav = document.querySelector('.four_liftNav')
    const lift_nav_title = document.querySelector('.four_liftNav_box h2')  
    const links = document.querySelectorAll('.four_liftNav a')
    const four_normal = document.querySelector('.four_normal')
    const four_run = document.querySelector('.four_run')
    
    //点击黄色标题部分，显示出4条“线路”
    let f = 0
    lift_nav_title.addEventListener('click',function(){
      f++
      if(f===1){
        lift_nav.style.opacity = 1
        lift_nav.style.transform = 'translateY(0px)'
      }
      if(f===2){
        lift_nav.style.opacity = 0
        lift_nav.style.transform = 'translateY(-46px)'
        f = 0
      }
    })

    // 对选择的元素数组进行遍历，link为元素本身，index为当前元素的索引
    links.forEach(function(link, index) {  
      // 为每个元素添加点击事件监听器
      link.addEventListener('click', function(event) {  
        // 阻止元素的默认点击事件（默认情况下点击锚链接会直接跳转到链接位置）
        event.preventDefault()
        
        // 切换透明度，使four_normal隐藏，four_run显示
        four_normal.style.opacity = '0'
        four_run.style.opacity = '1'
        
        // 获取点击的链接元素的href属性对应的目标元素（也就是要滚动到的目标位置）
        const target = document.querySelector(link.getAttribute('href'))
        // 获取目标元素的顶部距离页面顶部的距离，如果是前四个链接，就减去40px
        const position = target.offsetTop - (index < 4 ? 40 : 0)
        // 设置动画持续时间
        const duration = 1800  
        // 获取当前窗口滚动的距离
        const start = window.pageYOffset  
        // 计算目标位置与当前位置的距离
        const distance = position - start  
    
        // 定义滚动动画函数
        function scrollAnimation(startTime) {  
          // 计算从动画开始到现在过去的时间
          const elapsedTime = Date.now() - startTime
          // 计算当前应该滚动到的位置
          const positionNow = Math.min(distance, distance * (elapsedTime / duration)) + start  
          // 执行滚动到目标位置的操作
          window.scrollTo({  
            top: positionNow,  
            behavior: 'auto'  
          })
          // 如果动画时间未达到预设的持续时间，就继续执行动画
          if (elapsedTime < duration) {  
            requestAnimationFrame(function() {
              scrollAnimation(startTime)  
            })
          } else {
            // 当动画结束时，将four_normal显示，four_run隐藏
            four_normal.style.opacity = '1'
            four_run.style.opacity = '0'
          }
        }
        // 使用requestAnimationFrame方法来优化动画性能，这会告诉浏览器在下一次重绘之前执行scrollAnimation函数
        requestAnimationFrame(function() {  
          scrollAnimation(Date.now())   // 在函数中传入当前时间
        })
      })
    })
// 昼夜切换
    //获取昼夜切换按钮
    const mn_buttons = document.querySelectorAll('.sun_icon')
    
    let n = 0 //状态计数器，用于切换昼夜模式
    
    //遍历所有的昼夜切换按钮
    mn_buttons.forEach(function(button,index){ 
        //为每个按钮添加点击事件监听器
        button.addEventListener('click',function(){
            
            n++ //点击一次，状态计数器增加1
    
            //获取页面中各个要改变样式的元素
            const body = document.body
            const content = document.querySelector('.content')
            const title_home = document.querySelector('.title_home')
            const Calendar_box = document.querySelector('.Calendar_Drawing_box')
            const Calendar_child = document.querySelectorAll('.Calendar_child')
            
            if(n===1){
                //设置“夜晚”模式的样式
                body.style.background = 'url(images/Homepage/Purple_Starry_Sky.png)'
                body.style.color = 'white'
                content.style.backgroundColor = 'black'
                dw.style.color = 'white'
                rw.style.color = 'white'
                Calendar_box.style.backgroundColor = 'black'
                Calendar_child.forEach(function(child){
                    child.style.backgroundColor = 'white'
                    child.style.color = 'black'
                })
                //重新为所有的按钮添加鼠标移入和移出事件监听器，设置相应的样式，这是进行按钮状态同步的关键
                mn_buttons.forEach(function(button){
                    button.style.backgroundImage = 'url(images/logo/moon_icon.png)'
                    button.addEventListener('mouseenter',function(){
                        button.style.backgroundColor = 'pink'
                        button.style.backgroundImage = 'url(images/logo/sun_icon.png)'
                    })
                    button.addEventListener('mouseleave',function(){
                        button.style.backgroundColor = 'transparent'
                        button.style.backgroundImage = 'url(images/logo/moon_icon.png)'
                    })
                })
            }
    
            if(n===2){
                //设置“白天”模式的样式
                body.style.background = 'url(images/Homepage/pink_sky.webp)no-repeat'
                body.style.backgroundSize = '100% 100%'
                body.style.backgroundAttachment = 'fixed'
                body.style.color = 'black' 
                content.style.backgroundColor = 'white'
                dw.style.color = 'black'
                rw.style.color = 'black'
                Calendar_box.style.backgroundColor = '#6c0eff'
                Calendar_child.forEach(function(child){
                    child.style.backgroundColor = 'black'
                    child.style.color = 'white'
                })
                //重新为所有的按钮添加鼠标移入和移出事件监听器，设置相应的样式，这是进行按钮状态同步的关键
                mn_buttons.forEach(function(button){
                    button.style.backgroundImage = 'url(images/logo/sun_icon.png)'
                    button.addEventListener('mouseenter',function(){
                        button.style.backgroundColor = '#6c0eff'
                        button.style.backgroundImage = 'url(images/logo/moon_icon.png)'
                    })
                    button.addEventListener('mouseleave',function(){
                        button.style.backgroundColor = 'transparent'
                        button.style.backgroundImage = 'url(images/logo/sun_icon.png)'
                    })
                })
                n = 0 //重置状态计数器
            }
        })
    })