       // logo开场动画需要获取的元素
       const logo = document.querySelector('.logo')
       const bulb = document.querySelector('.bulb')
       const om = document.querySelector('.om')
       const ri = document.querySelector('.ri')
       const room =document.querySelector('.white-space')


       //获取第二个盒子的音频元素和滑动条元素
       const wsAudio = document.querySelector('.ws-audio')
       const wsVolumeSlider = document.querySelector('.ws-volumeSlider')
       //通过给滑动条绑定input事件，来获取value的值，并把值赋给音频的volume属性，实现音频音量随滚珠的滑动而调整大小
       wsVolumeSlider.addEventListener('input',function(){
           wsAudio.volume = wsVolumeSlider.value
       })
       const choice = document.querySelector('.choice')//这是第二个大盒子的元素

       const content = document.querySelector('.content')
       const whiteSpace = document.querySelector('.white-space-border')

       //第一个盒子的小人点击效果
       // omori小人点击效果,点击时切换图片
       const omori = document.querySelector('.omori img')
       const omoribox = document.querySelector('.omori')
       // 给人物图片路径设置一个数组对象，方便点击时切换图片
       const omoriArr = [
           {src:'images/Login_page/omori_1.png'},
           {src:'images/Login_page/omori_2_halfup.gif'},
           {src:'images/Login_page/omori_3_be_stunned.png'},
           {src:'images/Login_page/omori_4_Sit-to-stand_status.gif'},
           {src:'images/Login_page/omori_5_normal.png'},
           {src:'images/Login_page/omori_6_Play_the _violin.gif'}
       ]
       let i = 0
       omori.addEventListener('click',function(){
           i++
           if(i>5){
               i=0
           }
           omori.src = omoriArr[i].src
           if(i === 4){ 
               omoribox.nextElementSibling.style.opacity = 1
           }
           if(i>4){
               omoribox.nextElementSibling.style.opacity = 0
           }
       })

       //第三个盒子
       const loginbox = document.querySelector('.login') 
       // 输入框获取到焦点时，给laber添加向上缩小位移动画。输入框失去焦点时，给laber添加回退放大位移动画
       const username = document.querySelector('.username')
       const usernameLb = document.querySelector('.username-lb')
       const psd = document.querySelector('.password')
       const psdLb = document.querySelector('.password-lb')
       const sign_submit = document.querySelector('.sign-in')
        //给user表单添加“获取焦点”和“失去焦点”事件
       username.addEventListener('focus',function(){
           usernameLb.style.animation = 'lb-move .4s linear forwards'
           usernameLb.style.color = 'white'
           this.style.borderBottomColor = 'white'
       })
       username.addEventListener('blur',function(){
           if(this.value.length === 0){   /* 如果输入框的文本长度不大于0，则不触发return动画 */
           usernameLb.style.animation = 'lb-return .4s linear forwards'
           usernameLb.style.color = 'rgb(160, 160, 160)'
           this.style.borderBottomColor = 'rgb(160, 160, 160)'
           }
       })
       psd.addEventListener('focus',function(){
           psdLb.style.animation = 'lb-move .4s linear forwards'
           psdLb.style.color = 'white'
           this.style.borderBottomColor = 'white'
       })
       psd.addEventListener('blur',function(){
           if(this.value.length === 0){
           psdLb.style.animation = 'lb-return .4s linear forwards'
           psdLb.style.color = 'rgb(160, 160, 160)'
           this.style.borderBottomColor = 'rgb(160, 160, 160)'
           }
       })
       // 正则表达式验证函数
       function validateInput(regex, input) {
         return regex.test(input.value)
       }
     
       // 表单提交事件监听
       sign_submit.addEventListener('click', function(event) {
         event.preventDefault()  // 阻止表单默认提交行为
     
         // 定义正则表达式
         const usernameRegex = /^[a-zA-Z0-9_-]{4,16}$/   // 用户名正则表达式:表示允许用户名中包含字母（大小写）、数字、下划线和短横线,长度必须为4-16个字符之间。
         const passwordRegex = /^(?=.*[a-zA-Z])(?=.*\d)[a-zA-Z\d]{6,}$/  // 密码正则表达式：表示密码中只能包含数字和字母，且至少包含一个大写或小写字母和一个数字，长度至少为6个字符，。
     
         // 验证用户名和密码
         const isUsernameValid = validateInput(usernameRegex, username)
         const isPasswordValid = validateInput(passwordRegex, psd)
     
         // 根据验证结果执行相应逻辑
         if (isUsernameValid && isPasswordValid) {
           alert('验证通过，点击确定，1s后将跳转到主页')
           setTimeout(function(){
            window.location.href = 'Homepage.html'
           },1000)
        //    console.log('验证通过，点击确定，1s后将跳转到主页');
         } else {
             alert('验证失败，用户名至少包含4个字符。密码只能由字母和数字组成，长度至少为六位，且必须包含一个字母和一个数字')
        //    console.log('用户名或密码验证不通过');
         }
       });


       //第三个盒子的音频
       const duetVolumeSlider = document.querySelector('.log-volumeSlider')
       const duetAudio = document.querySelector('.duet-audio')
       duetVolumeSlider.addEventListener('input',function(){
           duetAudio.volume = duetVolumeSlider.value
       })


       // 开门动画，door的点击事件
       const door = document.querySelector('.door-imgs')
       const tv = document.querySelector('.tv')
       door.addEventListener('click',function(){   //给door添加点击事件，当点击door时，omori会走到门前，随后进行选择，选择open door，则会进行跳转到白色空间的盒子，执行开门函数，选择do nothing后，重新加载此网页
           setTimeout(function(){
               omori.src = 'images/Login_page/omori_5_normal.png'
               omoribox.nextElementSibling.style.opacity = 0
           },1000)
           setTimeout(function(){
               omori.src = 'images/Login_page/omori_walking.gif'
           omori.style.transform = 'rotate(90deg)'
           omoribox.style.left = '12%'
           },2000)
           // 小人步行到门前效果
           setTimeout( function(){
               if(omoribox.style.left === '12%'){
               omori.style.transform = 'rotate(0deg)'
               omori.src = 'images/Login_page/omori_Back_walking.gif'
               omoribox.style.top = '-70px'
           }
           },5500)
           setTimeout(function(){ //注意,不能用if包裹住setTimeout函数,只能用setTimeout包裹住if
                   whiteSpace.style.opacity = 0 //把第一个盒子隐藏掉
                   content.style.marginTop = '-699px' //切换到第二个盒子
                   choice.style.opacity = 1//第二个盒子缓缓显示出来
                   wsAudio.play()     //播放音频
                   wsAudio.volume = 0.1
                   wsAudio.loop = true
           },9000)

        //若选择“open door”选项则调用此函数
           function openDoor(){
               // 回到白色空间，门被打开
               wsAudio.pause()
               whiteSpace.style.opacity = 1
               content.style.marginTop = '0px'
               //开门动画
               door.style.animation = 'open .65s steps(5) forwards'
           
           setTimeout(function(){
               omoribox.style.top = '-100px' //omori走向门前
           },1500)
           setTimeout(function(){
               omori.style.opacity = 0  //随后消失
           }, 2000)
           // 关门效果
           setTimeout(function(){
               door.style.animation = 'close .65s steps(5) forwards'
           },3000)
           // 门关上之后切换到第三个盒子
           setTimeout(function(){
                   choice.style.opacity = 0
                   loginbox.style.opacity = 1
                   content.style.marginTop = '-1299px'
                   duetAudio.play()
                   duetAudio.volume = 0.1  //初始音量
                   duetAudio.loop = true   //循环播放
           },4000)
           }

       //第二个盒子的效果:若是选择opendoor,则跳转到登录界面
       // 若是选择do nothing则跳转到白色空间(第一个盒子)
           //通过事件委托来获取用户点击的选项
           const selectBox = document.querySelector('.select-box')// 获取选项的父元素
           selectBox.addEventListener('click',function(e){
               //通关环境对象e来获取点击对象的类名
               if(e.target.className === 'selection1'){
                   openDoor()
               }
               if(e.target.className === 'selection2'){
                   location.href = 'Login_page.html'
               }
           })
       })
       // logo开场动画 
       window.addEventListener('load',function(){
           bulb.style.opacity = 1
           setTimeout(function () {
               om.style.opacity = 1
               ri.style.opacity = 1
           }, 1500)  //延迟函数，该定时器在1.5s后触发
           setTimeout(function(){
               logo.style.animation = ' logomove 1.5s linear forwards'
           },2500)
           setTimeout(function(){
               room.style.opacity =1
           },4000)
           //等待logo动画加载完毕后，白色空间的盒子再显现出来
           setTimeout(function(){
               whiteSpace.style.opacity = 1
           },4500)
       }) 