

const pagesArr = document.querySelectorAll('.page')  //获取所有页面元素
const nextBtn = document.querySelector('.next')  //获取下一页按钮
const prevBtn = document.querySelector('.prev')  //获取上一页按钮
let i = 0  //设置当前页面索引
//遍历所有页面
pagesArr.forEach(function(page, index) {
  //给每个页面添加点击事件
  page.addEventListener('click', function() {
    const currentPage = this; //当前点击的页面
    const currentHalfPageLeft = this.children[1]  //当前页面的左半页
    const currentHalfPageRight = this.children[2]  //当前页面的右半页
    currentHalfPageRight.style.transform = 'rotateY(-180deg)'  //将当前右半页翻转
    currentHalfPageLeft.style.opacity = 0  //同时设置当前左半页的透明度为0，使其不可见
    setTimeout(function() {
      currentPage.style.zIndex = 0  //等待1秒后，设置当前页的层叠顺序为0，使其在其他页面之下
      currentHalfPageLeft.style.zIndex = 0  //同样设置当前半页的层叠顺序
      currentHalfPageRight.style.zIndex = 0  //同样设置当前半页的层叠顺序
    }, 1000)

    currentHalfPageRight.style.opacity = 0  //设置当前半页的透明度为0，使其不可见
    currentHalfPageLeft.style.opacity = 0  //设置当前半页的透明度为0，使其不可见
    currentPage.style.opacity = 0  //设置当前页的透明度为0，使其不可见

  })
})

// 当用户进入页面时，后退按钮的状态变为禁用
if(i === 0){
    prevBtn.disabled = true
    prevBtn.style.backgroundImage = 'url(images/Album-Real_world/gray-left_hand.png)'
}
//为下一页按钮添加点击事件
nextBtn.addEventListener('click', function() {
  if (i < pagesArr.length - 1) {
    pagesArr[i].click(); //模拟点击当前页，使其翻页
    i++ //增加页面索引
    nextBtn.disabled = false
    nextBtn.style.backgroundImage = 'url(images/Album-Real_world/right_hand.png)'
    prevBtn.disabled = false
    prevBtn.style.backgroundImage = 'url(images/Album-Real_world/left_hand.png)'
  }

  // 如果到达最后一页，禁用下一页按钮
  if (i === pagesArr.length - 1) {
    nextBtn.disabled = true
    nextBtn.style.backgroundImage = 'url(images/Album-Real_world/gray-right_hand.png)'
  }
});
prevBtn.addEventListener('click',function(){
  if (i > 0) {
    const zIndexARR = [8,7,6,5,4,3,2,1]
    const currentPage = pagesArr[i]  //当前点击的页面
    const currentHalfPageLeft = currentPage.children[1]  //当前页面的左半页
    const currentHalfPageRight = currentPage.children[2]  //当前页面的右半页
    // 前页
    const previousPage = pagesArr[i].previousElementSibling //上一个页面
    const previousHalfPageLeft = previousPage.children[1]   //上一个页面的左半页
    const previousHalfPageRight = previousPage.children[2]  //上一个页面的右半页
    // 后页
// 当前页面的左半页翻转时，当前页面的透明度为0，随后使上一个页面的透明度为1
    previousHalfPageRight.style.transform = 'rotateY(0deg)'  //恢复上一个左页面的状态
    currentHalfPageLeft.style.transform = 'rotateY(180deg)' //点击当前的左页面
    previousPage.style.zIndex = zIndexARR[i]
    previousHalfPageLeft.style.zIndex = zIndexARR[i]
    previousHalfPageRight.style.zIndex = zIndexARR[i]
    i--
    setTimeout(function(){
    previousHalfPageLeft.style.opacity = 1 
    },300)
    setTimeout(function(){
    previousPage.style.opacity = 1
    },360)
    previousHalfPageRight.style.opacity = 1
    currentHalfPageRight.style.opacity = 0  //设置当前半页的透明度为0，使其不可见
    currentHalfPageLeft.style.opacity = 0  //设置当前半页的透明度为0，使其不可见
    currentPage.style.opacity = 0  //设置当前页的透明度为0，使其不可见
    previousPage.style.zIndex = zIndexARR[i]
    previousHalfPageLeft.style.zIndex = zIndexARR[i]
    previousHalfPageRight.style.zIndex = zIndexARR[i]
    // 当左翻页翻到第一页时，则遍历所有页,并让它们的左半页“归位”
    if(i===0){
        for (let j = i; j < pagesArr.length; j++) {
            setTimeout(function() {
                pagesArr[j].children[1].style.transform = 'rotateY(0deg)'
            }, 0)
        }
    }
    // 当左翻页翻到第一页时，则遍历所有页的opacity的值为1
    if(i===0){
        setTimeout(function(){
            for (let j = i; j < pagesArr.length; j++) {
                pagesArr[j].style.opacity = 1
                 // 如果每一页都由左右两个半页组成，也需要将这两个半页的opacity设置为1
                pagesArr[j].children[1].style.opacity = 1  //左半页
                pagesArr[j].children[2].style.opacity = 1  //右半页
            }
        },1000)  //添加延迟函数是为了过渡自然
    }
    nextBtn.disabled = false
    nextBtn.style.backgroundImage = 'url(images/Album-Real_world/right_hand.png)'
    }
  // 最后，当左页面翻转到第一页时，禁用prev按钮    
  if(i===0){
      prevBtn.disabled = true
      prevBtn.style.backgroundImage = 'url(images/Album-Real_world/gray-left_hand.png)'
  }
})
const Album_title = document.querySelector('.Album_title')
const photos = Array.from(document.querySelectorAll('.photo_half'))
const pageBox = document.querySelector('.page_box')  //相册盒子
const gallery_box = document.querySelector('.photo_gallery')  //图片展示盒子
const gallery_box_img = document.querySelector('.photo_gallery img')  //图片展示盒子
const shift_key = document.querySelector('.shift_key')  //shift盒子
const gallery_textBox = document.querySelector('.photo_galleryText')  //日志文本盒子
const gallery_title = document.querySelector('.photo_galleryText h4') //日志标题
const gallery_text = document.querySelector('.photo_galleryText p')   //日志文本
const photoArr = [
{url:'images/Album-Real_world/FA_ALBUM_01.png',title:'12/25 - 圣诞节',text:'我的第一张照片！照片中是我最好的好朋友SUNNY，他正在调试他的新小提琴。为了能和他的姐姐MARI一起演出，他又重新开始上小提琴课了，真令人兴奋！'},
{url:'images/Album-Real_world/FA_ALBUM_02.png',title:'2/18 - 我的生日',text:'今天是我12岁的生日！我还以为朋友们都把这事忘了，没想到他们偷偷为我准备了草莓蛋糕，真是个惊喜。我感觉自己真是太幸运了...今年一定是美好的一年！'},
{url:'images/Album-Real_world/FA_ALBUM_03.png',title:'2/18 - 我的生日',text:'又一张大家的合影。这是我打开所有礼物后不久拍的！MARI送了我这本相册，其他人则为我买了相机胶卷。我一定会尽我所能，不辜负这些礼物。'},
{url:'images/Album-Real_world/FA_ALBUM_04.png',title:'2/18 - 我的生日',text:'凯就是这样我行我素...派对帽... 也...太多了...'},
{url:'images/Album-Real_world/FA_ALBUM_05.png',title:'2/18 - 我的生日',text:'SUNNY躺在沙发上玩游戏。SUNNY有点害羞，但他真的很擅长倾听。我总在伤心难过时向他倒苦水。有时我可能会觉得给他添麻烦了，但他似乎一点都不在意。'},
{url:'images/Album-Real_world/FA_ALBUM_06.png',title:'2/18 - 我的生日',text:'MARI和HERO在沙发上睡着了。他们在一起睡得真香... 嘻嘻... 希望他们不会介意我照一张照片。要是被mari的爸爸看见，情况可能就不妙咯...'},
{url:'images/Album-Real_world/FA_ALBUM_07.png',title:'3/9',text:'早餐过后，MARI和HERO在一起洗碗。我们和MARI和SUNNY 一起度过了这个周末。最近天气逐渐变暖，于是我们决定去公园玩。KEL说公园的灌木丛后面有个秘密湖泊，我们打算一起去看看！'},
{url:'images/Album-Real_world/FA_ALBUM_08.png',title:'3/9',text:'我们从公园回来了，但KEL依旧充满活力。他向HERO挑战掰手腕，但我们都已经知道结局了... HERO，手下留情呀...'},
{url:'images/Album-Real_world/FA_ALBUM_09.png',title:'3/9',text:'哎呀... 太遗憾了，KEL... 下次好运。'},
{url:'images/Album-Real_world/FA_ALBUM_10.png',title:'3/10',text:'凯对昨晚掰手腕输给英雄的事有些耿耿于怀，于是英雄准备凑过去亲亲抱抱他！凯看上去很不耐烦。啊，兄弟情...'},
{url:'images/Album-Real_world/FA_ALBUM_11.png',title:'3/10',text:'我正在给SUNNY介绍最近正在读的一本书。MARI趁我不注意，偷拿了我的相机，然后拍下了这张照片。我真应该好好看管自己的东西。'},
{url:'images/Album-Real_world/FA_ALBUM_12.png',title:'3/10',text:'大家全都和SUNNY的毛绒玩具抱在了一起。他有好多软软的玩偶啊！真希望可以永远躺在这里。'},
{url:'images/Album-Real_world/FA_ALBUM_13.png',title:'3/31',text:'已经是三月的最后一天了！我们和MARI一起在秘密湖泊那里野餐。MARI想给大家拍一张合照！说，茄子！'},
{url:'images/Album-Real_world/FA_ALBUM_14.png',title:'3/31',text:'除了我、HERO和MARI，大家都在吃完东西后睡倒了。在我拍照的时候发生了一些不幸的事情。呃...谢谢你，赫克托耳。之后我得用胶布把它遮上。'},
{url:'images/Album-Real_world/FA_ALBUM_15.png',title:'4/9',text:'在从学校回家的路上，我拍到了一张MARI背着SUNNY的照片，他肯定是在校车上睡着了。我觉得这一幕很可爱，于是赶快把相机拿了出来，拍到了这张绝无仅有的照片！唉...有时候我真希望我也有个兄弟姐妹。'},
{url:'images/Album-Real_world/FA_ALBUM_16.png',title:'4/21',text:'MARI正在教大家怎么编花冠！这张照片上，SUNNY和KEL正举着MARI编好的花冠。它看上去真完美，不是吗？可是MARI似乎还不太满意。'},
{url:'images/Album-Real_world/FA_ALBUM_17.png',title:'4/21',text:'SUNNY和KEL最后还是放弃了编花冠，他们偷偷溜走了，但是AUBREY和我很快就学会了！大家都认为花冠真的很适合我。只戴一朵花或许也就够了。'},
{url:'images/Album-Real_world/FA_ALBUM_18.png',title:'4/21',text:'HERO还在试着编花冠。虽然这费了他不少时间，但他花冠总算成行了。这种坚持不懈的精神真让人敬佩！'},
{url:'images/Album-Real_world/FA_ALBUM_19.png',title:'4/29',text:'今天的雨可真大！春雨总是来得很突然呢。AUBREY穿着新买的雨衣，让我给她拍张照片。粉色可是她最喜欢的颜色呢！'},
{url:'images/Album-Real_world/FA_ALBUM_20.png',title:'4/29',text:'AUBREY拒绝让KEL躲在伞下，但KEL似乎毫不介意。他说他喜欢雨水的味道。'},
{url:'images/Album-Real_world/FA_ALBUM_21.png',title:'4/29',text:'KEL真的就是这样我行我素啦...我们去了趟蜂玩堂，但是店主让KEL把雨衣放在外面，要不然店里的漫画就要全被凯弄湿了。非常抱歉，店主先生。'},
{url:'images/Album-Real_world/FA_ALBUM_22.png',title:'5/25',text:'最近在学校课业繁忙，但我们总算能抽出时间一起去公园玩了。KEL倒挂在树上。他真是个爬树大师！要是我也能像他一样无所畏惧就好了。'},
{url:'images/Album-Real_world/FA_ALBUM_23.png',title:'5/25',text:'MARI给每个人买了不同口味的冰棍！SUNNY的是柠檬味的，HERO的是根汁汽水味的，KEL的是橙子味的，AUBREY的是西瓜味的，而MARI则是是葡萄味的！我的这根是香蕉味的...尝起来还行。'},
{url:'images/Album-Real_world/FA_ALBUM_24.png',title:'5/25',text:'大家的鞋排成了一圈！猜猜看哪双鞋是谁的？'},
{url:'images/Album-Real_world/FA_ALBUM_25.png',title:'6/22',text:'今天是暑假的第一天，大家决定一起去海滩庆祝假期！西瓜是AUBREY的最爱。'},
{url:'images/Album-Real_world/FA_ALBUM_26.png',title:'6/22',text:'KEL正在用清爽的香橙乔汽水解暑！我不太想离他太近，要不然我的相机可能就要遭殃了。KEL把饮料弄洒已经是公认的事实了。'},
{url:'images/Album-Real_world/FA_ALBUM_27.png',title:'6/22',text:'我们把SUNNY埋到了沙子里！花了我们好长时间，但至少他看上去真的蛮享受的。我不确定他需不需要我们把他从沙堆里扒出来。在那之前我最好还是陪着他吧。'},
{url:'images/Album-Real_world/FA_ALBUM_28.png',title:'6/22',text:'ARI说她想把皮肤晒出健康的古铜色！我还挺害怕在阳光下睡着的，因为我很容易被晒伤。嗯...我也不太确定KEL在干什么，但至少他看上去很开心。'},
{url:'images/Album-Real_world/FA_ALBUM_29.png',title:'6/22',text:'HERO趴在MARI身上睡着了。他一定是游泳游累了吧。好吧...看来MARI最后还是没法晒出古铜色了。'},
{url:'images/Album-Real_world/FA_ALBUM_30.png',title:'6/22',text:'在准备回家的时候，我成功抓拍到了这天的最后一张照片，是MARI和HERO在一起！他们看上去真开心。好般配的一对呀！'},
{url:'images/Album-Real_world/FA_ALBUM_31.png',title:'7/20-SUNNY的生日',text:'耶！SUNNY今天12岁了！虽然我和SUNNY、AUBREY还有KEL都市同一年级的，但SUNNY还是我们当中最小的那个。他就是我们中的小宝宝，我们一定要好好照顾他！'},
{url:'images/Album-Real_world/FA_ALBUM_32.png',title:'7/20-SUNNY的生日',text:'SUNNY从MAR和HERO那里收到了一份超大的礼物！嗯...我挺好奇里面到底是什么。'},
{url:'images/Album-Real_world/FA_ALBUM_33.png',title:'7/20-SUNNY的生日',text:'虽然从照片里看不到，但MARI和HERO送了SUNNY一整套超级大的积木。但SUNNY似乎对这个礼物盒更感兴趣一些。他这样子简直就像MARI新养的猫猫——喵呜！'},
{url:'images/Album-Real_world/FA_ALBUM_34.png',title:'7/20-SUNNY的生日',text:'SUNNY不愿意从盒子里出来，KEL甚至还放了两个食物碗在里面，我想这里以后就是SUNNY和喵呜的新家了。'},
{url:'images/Album-Real_world/FA_ALBUM_35.png',title:'8/4',text:'我们今天要去抓甲壳虫！KEL准备扑向下一个受害者！哦对，SUNNY也在呢。不过他看上去快要睡着了。'},
{url:'images/Album-Real_world/FA_ALBUM_36.png',title:'8/4',text:'MARI说这只甲壳虫是一只大楸型虫。它突然从树上掉下来，吓了大家一跳！HERO甚至看都不敢看。'},
{url:'images/Album-Real_world/FA_ALBUM_37.png',title:'8/14',text:'嗒--哒！我们忙活了一整个夏天，在SUNNY家的后院搭了座树屋！今天它终于完工了。HERO和他的爸爸承担了大部分的工作，但AUBREY和我帮忙做了很多纸花来装饰窗台！要我说，我们大家都超棒的！'},
{url:'images/Album-Real_world/FA_ALBUM_38.png',title:'8/14',text:'我去了趟卫生间，回来就发现了这张照片... KEL说这张照片只是个小小的意外，但我对此表示怀疑...'},
{url:'images/Album-Real_world/FA_ALBUM_39.png',title:'8/16',text:'我们大家一起在新建的树屋里玩！看来SUNNY终于开始读我之前给他介绍过的书了！我希想每天都在这个树屋里度过，但遗憾的是暑假快要结束了。希望下个夏天我们还能在树屋里一起度过！'},
{url:'images/Album-Real_world/FA_ALBUM_40.png',title:'8/18',text:'我们大家一起去蜂玩堂读了最新一期的《太空船长男孩》！我们全都沉迷其中！等到开学后，大家肯定都在讨论这部漫画。'},
{url:'images/Album-Real_world/FA_ALBUM_41.png',title:'9/6',text:'我正在和KEL、HERO和AUBREY一起玩牌。它们的心情全都写在脸上，一下子就被看穿啦！MARI亲手给大家烤了曲奇饼。像往常一样，上面洒满了巧克力碎，非常美味。'},
{url:'images/Album-Real_world/FA_ALBUM_42.png',title:'9/6',text:'看来我有一手必胜的牌，嘿嘿...而且大家都没发现...'},
{url:'images/Album-Real_world/FA_ALBUM_43.png',title:'9/9',text:'今天是开学的第一天！我、SUNNY、KEL和AUBREY很早就起床啦。AUBREY真的超级上镜呢！'},
{url:'images/Album-Real_world/FA_ALBUM_44.png',title:'9/9',text:'唉...再见了，夏天！明年再见...'},
{url:'images/Album-Real_world/FA_ALBUM_45.png',title:'9/9',text:' SUNNY给MARI一个大大的拥抱！MARI为了报考大学，每天都要课外补习，很晚才回家。我最近经常和SUNNY一起玩，但我知道他还是很想念MARI。'},
{url:'images/Album-Real_world/FA_ALBUM_46.png',title:'9/22',text:' MARI正在为下个月的演奏会做准备。我们都会去看的！这将是MARI和SUNNY第一次同台演出，但我相信他们一定会表现得很出彩！我们大家都会在观众席上为他们加油！'},
{url:'images/Album-Real_world/FA_ALBUM_47.png',title:'9/22',text:' MARI现在有点羞于上镜，因为她刚刚在弹奏时犯了个小错误。MARI！你能行的！根本不会有人注意到这点小细节啦！'},
{url:'images/Album-Real_world/FA_ALBUM_48.png',title:'9/22',text:'在我们的请求下，SUNNY终于愿意和MARI一起排练啦...嘿嘿...虽然他们还需要磨合一下，但合奏听起来已经很棒了！我就知道他们会表现得很出色。加油，MARI！加油，SUNNY！你们一定没问题的！'}
] 
photos.forEach(function(photo,index){
photo.addEventListener('click',function(e){
    e.stopPropagation()  //阻止冒泡，这样子点击图片，也不会受到父元素的点击切换页数的效果影响
    pageBox.style.top = '150%'   //相册盒子位移到底部
    pageBox.style.opacity = 0   //相册盒子位移的同时隐藏
    gallery_box.style.bottom = 0  //图片展示盒子从底部往上弹出
    gallery_box.style.opacity =1   //图片展示盒子弹出的时候同时进行显现
    nextBtn.style.opacity = 0
    prevBtn.style.opacity = 0
    gallery_box_img.src = photoArr[index].url  //根据点击到的图片，进行实时切换
    gallery_title.innerHTML = photoArr[index].title
    gallery_text.innerHTML = photoArr[index].text
    Album_title.style.opacity = 0  //标题隐藏
})
})
let xCount = 0  //用来追踪按下x键的次数
document.addEventListener('keyup',function(e){
// console.log(e);
if(e.key === 'Shift'){   //首字母必须大写
    shift_key.style.opacity = 0  //shift盒子隐藏
    gallery_textBox.style.bottom = 0  //日志文本盒子弹出
    gallery_textBox.style.opacity = 1  //日志文本盒子显示
}
if(e.key === 'x'){
    xCount++
    if(xCount===1){
    shift_key.style.opacity = 1  //shift盒子隐藏
    gallery_textBox.style.bottom = 1  //日志文本盒子弹出
    gallery_textBox.style.opacity = 0  //日志文本盒子显示
    }
    if(xCount===2){
        //复原点击图片之前的相册状态
        pageBox.style.top = '-9.14%'
        pageBox.style.opacity = 1
        gallery_box.style.bottom ='-200%'
        gallery_box.style.opacity = 0
        nextBtn.style.opacity = 1
        prevBtn.style.opacity = 1
        Album_title.style.opacity = 1
        xCount = 0 //次数归0

    }
}
})