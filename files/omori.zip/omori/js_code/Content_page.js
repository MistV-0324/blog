     // 固定导航的显现
     const fx_nav = document.querySelector('.fixed_nav_box')
     // 1、知识点：scrollTop，offsetTop
     // 获取header的高度，并且使其到达固定位置时颜色加深
     function scHeader(){
         // document.documentElement 是html元素的获取方式，想要获取页面的中被卷去的高度，必须要获取html元素
         // scrollTop为可读写属性，可读写的意思：就是既可以获取，又可以赋值
         const sctop = document.documentElement.scrollTop
         const content = document.querySelector('.content')
         const contentOt = content.offsetTop
         if(sctop >= contentOt){  //sctop 是页面滚动的高度，而offsetTop元素的上边距。这两个值不太可能完全相等。所以可以使用一个范围来判断是否滚动到了指定位置。
             fx_nav.style.backgroundColor =' rgba(63, 7, 153)'
             fx_nav.style.opacity = 1
             fx_nav.style.top = '0px'
         }
         else{
             fx_nav.style.backgroundColor = 'rgba(63, 7, 153, .3)'
             fx_nav.style.opacity = 0;
             fx_nav.style.top = '-30px'
         }
     }
     window.addEventListener('scroll', scHeader)
     
     // 创建一个函数处理人物的切换,梦境四人
     function setupCharacterToggle_1(characterNumber) {
         // 获取指定人物的face图片元素
         const face_img = document.querySelector(`.character_wrapper_1 .character_${characterNumber} .face`)
         // 获取指定人物的fullbody图片元素
         const fullbody_img = document.querySelector(`.character_wrapper_1 .character_${characterNumber} .fullbody`)
         // 获取指定人物的face和fullbody选项元素
         const character_selection = document.querySelectorAll(`.character_wrapper_1 .character_${characterNumber} .selections p`)
         // 获取指定人物的简介栏元素
         const character_column = document.querySelector(`.character_wrapper_1 .character_${characterNumber} .introduction_column`)
         // 用于记录当前选择状态的变量
         let o = 0
         // 对每个选项元素进行处理
         character_selection.forEach(function(face_full, index) {
             // 当选项被点击时
             face_full.addEventListener('click', function() {
                 // 将o值加1
                 o++
                 // 如果o为1，说明切换到fullbody状态
                 if(o === 1) {
                     // 设置fullbody选项的边框颜色
                     character_selection[1].style.borderBottom = '4px solid #6c0eff'
                     // 移除face选项的边框颜色
                     character_selection[0].style.borderBottom = 'none'
                     // 隐藏简介栏
                     character_column.style.opacity = 0
                     // 隐藏face图片
                     face_img.style.opacity = 0
                     // 显示fullbody图片
                     fullbody_img.style.opacity = 1
                 }
                 // 如果o为2，说明切换回face状态
                 if(o === 2) {
                     // 设置face选项的边框颜色
                     character_selection[0].style.borderBottom = '4px solid #6c0eff'
                     // 移除fullbody选项的边框颜色
                     character_selection[1].style.borderBottom = 'none'
                     // 显示简介栏
                     character_column.style.opacity = 1
                     // 显示face图片
                     face_img.style.opacity = 1
                     // 隐藏fullbody图片
                     fullbody_img.style.opacity = 0
                     // 重置o值为0，为下一次切换做准备
                     o = 0
                 }
             })
         });
     }

     // 对每个人物进行设置
     for(let i = 1; i <= 4; i++) {
         // 调用函数，设置人物的切换
         setupCharacterToggle_1(i)
     }

 // 获取四个dw人物的头像框,点击选项框分别显示出对应的人物介绍栏盒子
     const headshots_dw = document.querySelectorAll('.characters_box_1 .character_headshots_box .character_headshot')
     const characters_dw = document.querySelectorAll('.character_wrapper_1 .character')
     headshots_dw.forEach(function(headshot, index) {
         headshot.addEventListener('click', function() {
             characters_dw.forEach(function(character, charIndex) {
                 if(charIndex === index) {
                     character.classList.add('show') //添加“show”类名使其盒子的层级提前
                     character.style.zIndex = 1
                     character.style.opacity = 1
                 } else { //使其它盒子的层级都变成0
                     character.classList.remove('show')
                     character.style.zIndex = 0
                     character.style.opacity = 0
                 }
             })
         })
     })
 
 // 创建一个函数处理人物的切换,现实四人
         function setupCharacterToggle_2(characterNumber) {
         // 获取指定人物的face图片元素
         const face_img = document.querySelector(`.character_wrapper_2 .character_${characterNumber} .face`)
         // 获取指定人物的fullbody图片元素
         const fullbody_img = document.querySelector(`.character_wrapper_2 .character_${characterNumber} .fullbody`)
         // 获取指定人物的face和fullbody选项元素
         const character_selection = document.querySelectorAll(`.character_wrapper_2 .character_${characterNumber} .selections p`)
         // 获取指定人物的简介栏元素
         const character_column = document.querySelector(`.character_wrapper_2 .character_${characterNumber} .introduction_column`)
         // 用于记录当前选择状态的变量
         let o = 0
         // 对每个选项元素进行处理
         character_selection.forEach(function(face_full, index) {
             // 当选项被点击时
             face_full.addEventListener('click', function() {
                 // 将o值加1
                 o++
                 // 如果o为1，说明切换到fullbody状态
                 if(o === 1) {
                     // 设置fullbody选项的边框颜色
                     character_selection[1].style.borderBottom = '4px solid #6c0eff'
                     // 移除face选项的边框颜色
                     character_selection[0].style.borderBottom = 'none'
                     // 隐藏简介栏
                     character_column.style.opacity = 0
                     // 隐藏face图片
                     face_img.style.opacity = 0
                     // 显示fullbody图片
                     fullbody_img.style.opacity = 1
                 }
                 // 如果o为2，说明切换回face状态
                 if(o === 2) {
                     // 设置face选项的边框颜色
                     character_selection[0].style.borderBottom = '4px solid #6c0eff'
                     // 移除fullbody选项的边框颜色
                     character_selection[1].style.borderBottom = 'none'
                     // 显示简介栏
                     character_column.style.opacity = 1
                     // 显示face图片
                     face_img.style.opacity = 1
                     // 隐藏fullbody图片
                     fullbody_img.style.opacity = 0
                     // 重置o值为0，为下一次切换做准备
                     o = 0
                 }
             })
         })
     }

     // 对每个人物进行设置
     for(let j = 1; j <= 4; j++) {
         // 调用函数，设置人物的切换
         setupCharacterToggle_2(j)
     }

 // 获取四个rw人物的头像框,点击选项框分别显示出对应的人物介绍栏盒子
     const headshots_rw = document.querySelectorAll('.characters_box_2 .character_headshots_box .character_headshot')
     const characters_rw = document.querySelectorAll('.character_wrapper_2 .character')
     headshots_rw.forEach(function(headshot, index) {
         headshot.addEventListener('click', function() {
             characters_rw.forEach(function(character, charIndex) {
                 if(charIndex === index) {
                     character.classList.add('show') //添加“show”类名使其盒子的层级提前
                     character.style.zIndex = 1
                     character.style.opacity = 1
                 } else { //使其它盒子的层级都变成0
                     character.classList.remove('show')
                     character.style.zIndex = 0
                     character.style.opacity = 0
                 }
             })
         })
     })
        //遍历两个页面中的相册，点击它们实现页面跳转
        const albums = document.querySelectorAll('.album')
        albums.forEach(function(album){
            albums[0].addEventListener('click',function(){
                window.location.href = 'Rw-Album_page.html' 
            })
            albums[1].addEventListener('click',function(){
                window.location.href = 'Dw-Album_page.html' 
            })
        })
    //电梯导航
        // 使用querySelectorAll方法选择所有包含href属性值以"#"开头的.nav a元素
        const lift_nav = document.querySelector('.four_liftNav')
        const lift_nav_title = document.querySelector('.four_liftNav_box h2')  
        const links = document.querySelectorAll('.four_liftNav a')
        const four_normal = document.querySelector('.four_normal')
        const four_run = document.querySelector('.four_run')
        
        //点击黄色标题部分，显示出4条“线路”
        let f = 0
        lift_nav_title.addEventListener('click',function(){
          f++
          if(f===1){
            lift_nav.style.opacity = 1
            lift_nav.style.transform = 'translateY(0px)'
          }
          if(f===2){
            lift_nav.style.opacity = 0
            lift_nav.style.transform = 'translateY(-46px)'
            f = 0
          }
        })

        // 对选择的元素数组进行遍历，link为元素本身，index为当前元素的索引
        links.forEach(function(link, index) {  
          // 为每个元素添加点击事件监听器
          link.addEventListener('click', function(event) {  
            // 阻止元素的默认点击事件（默认情况下点击锚链接会直接跳转到链接位置）
            event.preventDefault();  
            
            // 切换透明度，使four_normal隐藏，four_run显示
            four_normal.style.opacity = '0'
            four_run.style.opacity = '1'
            
            // 获取点击的链接元素的href属性对应的目标元素（也就是要滚动到的目标位置）
            const target = document.querySelector(link.getAttribute('href'))
            // 获取目标元素的顶部距离页面顶部的距离，如果是前四个链接，就减去40px
            const position = target.offsetTop - (index < 4 ? 29 : 0)
            // 设置动画持续时间
            const duration = 2000
            // 获取当前窗口滚动的距离
            const start = window.pageYOffset  
            // 计算目标位置与当前位置的距离
            const distance = position - start  
        
            // 定义滚动动画函数
            function scrollAnimation(startTime) {  
              // 计算从动画开始到现在过去的时间
              const elapsedTime = Date.now() - startTime  
              // 计算当前应该滚动到的位置
              const positionNow = Math.min(distance, distance * (elapsedTime / duration)) + start  
              // 执行滚动到目标位置的操作
              window.scrollTo({  
                top: positionNow,  
                behavior: 'auto'  
              })
              // 如果动画时间未达到预设的持续时间，就继续执行动画
              if (elapsedTime < duration) {  
                requestAnimationFrame(function() {
                  scrollAnimation(startTime)  
                })
              } else {
                // 当动画结束时，将four_normal显示，four_run隐藏
                four_normal.style.opacity = '1'
                four_run.style.opacity = '0'
              }
            }
            // 使用requestAnimationFrame方法来优化动画性能，这会告诉浏览器在下一次重绘之前执行scrollAnimation函数
            requestAnimationFrame(function() {  
              scrollAnimation(Date.now()) // 在函数中传入当前时间
            })
          })
        })
    // 昼夜切换
        //获取昼夜切换按钮
        const mn_buttons = document.querySelectorAll('.sun_icon')
        let n = 0 //状态计数器，用于切换昼夜模式
        
        //遍历所有的昼夜切换按钮
        mn_buttons.forEach(function(button,index){ 
            //为每个按钮添加点击事件监听器
            button.addEventListener('click',function(){
                
                n++ //点击一次，状态计数器增加1
        
                //获取页面中各个要改变样式的元素
                const body = document.body
                const content = document.querySelector('.content')
                const characters = document.querySelectorAll('.character')
                if(n===1){
                    //设置“夜晚”模式的样式
                    body.style.background = 'url(images/Homepage/Purple_Starry_Sky.png)'
                    body.style.color = 'white'
                    content.style.backgroundColor = 'black'
                    characters.forEach(function(character){
                    character.style.backgroundColor = 'black'
                })
                    //重新为所有的按钮添加鼠标移入和移出事件监听器，设置相应的样式，这是进行按钮状态同步的关键
                    mn_buttons.forEach(function(button){
                        button.style.backgroundImage = 'url(images/logo/moon_icon.png)'
                        button.addEventListener('mouseenter',function(){
                            button.style.backgroundColor = 'pink'
                            button.style.backgroundImage = 'url(images/logo/sun_icon.png)'
                        })
                        button.addEventListener('mouseleave',function(){
                            button.style.backgroundColor = 'transparent'
                            button.style.backgroundImage = 'url(images/logo/moon_icon.png)'
                        })
                    })
                }
        
                if(n===2){
                    //设置“白天”模式的样式
                    body.style.background = 'url(images/Homepage/pink_sky.webp)no-repeat'
                    body.style.backgroundSize = '100% 100%'
                    body.style.backgroundAttachment = 'fixed'
                    body.style.color = 'black' 
                    content.style.backgroundColor = 'white'
                    characters.forEach(function(character){
                    character.style.backgroundColor = 'white'
                })
                    //重新为所有的按钮添加鼠标移入和移出事件监听器，设置相应的样式，这是进行按钮状态同步的关键
                    mn_buttons.forEach(function(button){
                        button.style.backgroundImage = 'url(images/logo/sun_icon.png)'
                        button.addEventListener('mouseenter',function(){
                            button.style.backgroundColor = '#6c0eff'
                            button.style.backgroundImage = 'url(images/logo/moon_icon.png)'
                        })
                        button.addEventListener('mouseleave',function(){
                            button.style.backgroundColor = 'transparent'
                            button.style.backgroundImage = 'url(images/logo/sun_icon.png)'
                        })
                    })
                    n = 0 //重置状态计数器
                }
            })
        })